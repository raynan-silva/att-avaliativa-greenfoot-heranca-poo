import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.util.List;
import java.util.ArrayList;

/**
 * Write a description of class MyWorld here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class World1 extends Menu
{
    private boolean gamestart = true;
    private boolean gameRunning = true;
    public Lives live = new Lives();
    public BlackCat Bcat= new BlackCat();
    
    public sessionScore gameScore = new sessionScore();
    public Counter scoreTracker = new Counter(gameScore,live);
    /**;
     * Constructor for objects of class MyWorld.
     * 
     */
    public World1(){
        addObject(scoreTracker, 900, 30);
        int  liveCounter = live.getValue();
        if(gamestart == true)
            prepare();
        
    }
    
    /**
     * Prepare the world for the start of the program.
     * That is: create the initial objects and add them to the world.
     */
    private void prepare()
    {
        World2 nextWorld = new World2();
        nextWorld.setup(live, Bcat, scoreTracker,gameScore);
        enemy dog = new enemy();
        addObject(scoreTracker, 900, 30);
        addObject(live,30, 28);
        enemy dog2 = new enemy();
        addObject(new Door(live, Bcat, scoreTracker, gameScore), 1075, 92);        
        groundH(0,600,17,"MediumPlatform");
        groundH(260,450,10,"MediumPlatform");
        groundH(550,300,9,"MediumPlatform");
        groundH(260,150,9,"MediumPlatform");
        groundH(210,300,1,"VerticlePlatform");
        groundH(153,375,1,"MediumPlatform");
        groundH(25,225,1,"MediumPlatform");
        groundH(1025,150,2,"MediumPlatform");
        addObject(dog2, 600, 250);
        addObject (Bcat, 15, 550);
        addObject(dog, 400, 100);
        addObject(new enemy(), 300, 400);
        addObject(new Invisivel(), 930, 450);
        addObject(new Invisivel(), 300, 400);
        gamestart = false;
    }
    private void gameOver(){
        //gameOver gameOverScreen = new gameOver();
        //addObject(gameOverScreen, 550,300);
    }
}
