import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.util.List;
import java.util.ArrayList;

/**
 * Door is responsible for scene changes when the cat reaches the end of a
 * level.
 */
public class Door extends Actor {
    private Lives lives;
    private BlackCat cat;
    private ScoreBoard sb;
    private Counter counter;
    private sessionScore score;

    public Door(Lives lives, BlackCat cat, Counter counter, sessionScore score) {
        this.lives = lives;
        this.cat = cat;
        this.sb = sb;
        this.counter = counter;
        this.score = score;
    }

    public void act() {
        checkForCat();
    }

    public void checkForCat() {
    if (isTouching(BlackCat.class)) {
        // Remove shared actors from the current world
        if (cat.getWorld() != null) cat.getWorld().removeObject(cat);
        if (counter.getWorld() != null) counter.getWorld().removeObject(counter);
        if (lives.getWorld() != null) lives.getWorld().removeObject(lives);

        // Figure out which world we're in
        World current = getWorld();
        World nextWorld = null;

        if (current instanceof World1) {
            nextWorld = new World2();
            ((World2)nextWorld).setup(lives, cat, counter, score);
        } else if (current instanceof World2) {
            nextWorld = new World3(); // you may need to create a new constructor to pass the shared actors back
            ((World3)nextWorld).setup(lives, cat, counter, score);
        }

        if (nextWorld != null) {
            Greenfoot.setWorld(nextWorld);
        }
    }
  }

}