import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
/**
 * Write a description of class BlackCat here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class BlackCat extends Actor
{
    private GifImage movingCat = new GifImage("Player_Cat-resized.gif");
    private GifImage jumpingCat = new GifImage("jumpingCat.gif");
    private GreenfootImage stillCat = new GreenfootImage("stillCat.png");
    private GreenfootImage catSitLeft = new GreenfootImage("catSitLeft.png");
    private GifImage leftFacing = new GifImage("cat-left.gif");
    private String key;
    private boolean attacking = false;
    private int speed=7;
    private int acceleration=1;
    private int accelAmt=-10;
    private int vertSpeed=0;
    private boolean jumping;
    private int jumpStrength = 18;
    public int lives = 9;
    private boolean canAttack = false;
    private boolean doubleJump = false;
    private int jumpCount = 0;
    private int jumpAnimationLoop = 0;
    private int timer = 500;
    private int attackCount = 1;
    private int attackTimer = 0;
    public Lives live;
    public String Orientation = new String("null");
    public BlackCat(){
        
    }
    /**
     * Act - do whatever the BlackCat wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act()
    {
        key = Greenfoot.getKey();  
        movement();
        jumpHandler();
        DoubleJumpHandler();
        animationHandler();     
        //within jump handler try adding "space" to double jump
        checkFall();
        checkDown();
        checkRightWall();
        checkLeftWall();
        attackHandler();
        livesHandler();
        
    }
    public void movement()
    {
        if (Greenfoot.isKeyDown("a")){
            setLocation(getX() - speed, getY());
        }
        if (Greenfoot.isKeyDown("d")){
            setLocation(getX() + speed, getY());
        }
        // Sprinting
        if (Greenfoot.isKeyDown("shift")) {
            if (Greenfoot.isKeyDown("a"))
                setLocation(getX() - 2, getY());
            else if (Greenfoot.isKeyDown("d"))
                setLocation(getX() + 2, getY());
        }
    }
    
    private void jumpHandler()
    {
        if (Greenfoot.isKeyDown("w") && onGround()) {
            if (jumpCount < 2) {  // Allow only two jumps
                jump();
                jumpCount++;
            }
        }
    }
    private void DoubleJumpHandler(){
        if(doubleJump == true){
            if(!onGround()){   
                if(Greenfoot.isKeyDown("space") && jumpCount < 3){
                    {
                        jumpAnimationLoop = 0;
                        jump();
                        jumpCount++;
                        
                    }
                }
            }
        }
    }
    public void checkFall()
    {
        if (onGround()) {
            vertSpeed = 0;
            jumping = false;
            jumpCount = 0; // Reset jumps when touching the ground
            jumpAnimationLoop = 0;
        } else {
            fall();
        }
    }

    private void jump()
    {
        vertSpeed = -jumpStrength;
        jumping = true;

    }
    
    public boolean onGround()
    {
        Ground under = null;
        int counter = 1;
        int max = vertSpeed;
        while (counter <= max && under == null) {
            under = (Ground) getOneObjectAtOffset(0, getImage().getHeight() / 2 + counter, Ground.class);
            counter++;
        }
        if (under != null) {
            int newY = under.getY() - (under.getImage().getHeight() / 2) - (getImage().getHeight() / 2) - 1;
            setLocation(getX(), newY);
        }
        return under != null;
    }
    
    public void fall()
    {
        setLocation(getX(), getY() + vertSpeed);
        vertSpeed += acceleration;
    }
    private void animationHandler(){
        if(Greenfoot.isKeyDown("d")){
            setImage(movingCat.getCurrentImage());
            Orientation = "right";
        }else if(Greenfoot.isKeyDown("a")){
            setImage(leftFacing.getCurrentImage());
            Orientation = "left";
        }
        else if(onGround()){
            if(Orientation == "right")
            setImage(stillCat);
            if(Orientation == "left")
            setImage(catSitLeft);
        }
        if(Greenfoot.isKeyDown("w")){
            jumpAnimation();
        }
        if(jumping == true && Greenfoot.isKeyDown("space")){
            jumpAnimation();
        }
    }
    private void jumpAnimation(){
         if(jumpAnimationLoop < 10){
                for(int x = 0; x < 4; x++){
                    setImage(jumpingCat.getCurrentImage());
                }
                jumpAnimationLoop++;
            }
            else if(jumpAnimationLoop > 10){
                setImage(movingCat.getCurrentImage());
            }
    }
    
    //Checks if there is an object above the cat and if so calls bopHead.
    private boolean checkDown(){
        //gets BlackCat height. Gets the height above BlackCat if there is an ground
        //object above and if so calls the bopHead method.
        int catHeight = getImage().getHeight();
        int yDistance = catHeight/-2; 
        Actor ceiling = getOneObjectAtOffset(0, yDistance, Ground.class);
        if (ceiling == null) return false;
        bopHead(ceiling);
        return true;
    }
    
    //Sets the cats height to make sure it can't jump through an object from
    //the ground class.
    private void bopHead(Actor ceiling)
    {  
        int ceilingHeight = ceiling.getImage().getHeight();
        int newY = ceiling.getY()+(ceilingHeight+getImage().getHeight())/2;
        setLocation(getX(), newY);
    }
    
    //Checks if there is a wall to the right of the cat. If so calls 
    //rightWallStop
    private boolean checkRightWall(){
        int catWidth = getImage().getWidth();
        int rightXDistance = catWidth/2;
        Actor rightWall = getOneObjectAtOffset(rightXDistance, 0, Ground.class);
        if (rightWall == null) return false;
        rightWallStop(rightWall);
        return true;
    }
    
    //Checks if there is a wall to the left of the cat. If so calls 
    //leftWallStop
    private boolean checkLeftWall(){
        int catWidth = getImage().getWidth();
        int leftXDistance = catWidth/-2;
        Actor leftWall = getOneObjectAtOffset(leftXDistance, 0, Ground.class);
        if (leftWall == null) return false;
        leftWallStop(leftWall);
        return true;
    }
    
    //Stops the player from being able to move through the wall
    private void leftWallStop(Actor leftWall)
    {
        
        int wallWidth = leftWall.getImage().getWidth();
        int newX = leftWall.getX()+(wallWidth+getImage().getWidth())/2;
        setLocation(newX, getY());
    }
    //Stops the player from being able to move through the wall
    private void rightWallStop(Actor rightWall)
    {
        int wallWidth = rightWall.getImage().getWidth();
        int newX = rightWall.getX()-(wallWidth+getImage().getWidth())/2;
        setLocation(newX, getY());
    }
    private void attackHandler(){
        if(canAttack){
            if(Greenfoot.isKeyDown("e") && attackTimer > 10000){
                if(attackCount > 0){
                attack attack = new attack();
                getWorld().addObject(attack, getX(), getY());
                if(Orientation == "right")
                attack.move(75);
                if(Orientation == "left")
                attack.move(-65);
                attackTimer = 0;
                }
                attackCount =  attackCount - 1;
            }
            {
            attackCount = 1;
            if(attackTimer <= 10000)
            attackTimer = attackTimer + 500;
            }
        }
    }
    
        private void livesHandler(){
        World world= getWorld();
        Lives lives = (Lives) getWorld().getObjects(Lives.class).get(0);
        if (isTouching(Obstacles.class)){
            long respawnTime = System.currentTimeMillis();
            lives.SubtractLives();
            if (getWorld() instanceof World2) {
                setLocation(15, 100);
            }else{
            setLocation(15, 550);
        }
        if(lives.getValue() <= 7)
        doubleJump = true;
        if(lives.getValue() <= 5)
        canAttack = true;
        if (lives.getValue() <= 0){
        getWorld().removeObject(this);
        }
        }
}
}
