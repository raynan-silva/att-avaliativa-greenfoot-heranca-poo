import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class World2 here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class World2 extends Menu

{
    private boolean gamestart = true;
    
    //public World1 previousWorld = new World1(live, Bcat, bruh, scoreTracker, gameScore);
    /**
     * Constructor for objects of class World2.
     * 
     */
     public World2()
    {   
        prepare();
    }
    public void setup(Lives lives, BlackCat cat, Counter counter, sessionScore ss){
        addObject(cat, 15, 50);
        //addObject(sb, 900, 30);
        addObject(lives, 30, 28);
        addObject(counter, 900, 30);
        addObject(new Door(lives, cat, counter, ss), 1075, 540);
        prepare();
    }
    
    /**
     * Prepare the world for the start of the program.
     * That is: create the initial objects and add them to the world.
     */
    private void prepare()
    {
        groundH(10,600,17,"MediumPlatform");
        groundH(0,275,3,"VerticlePlatform");
        groundH(280,125,10,"MediumPlatform");
        groundH(280,278,10,"MediumPlatform");
        groundH(450,390,8,"MediumPlatform");
        groundH(994,436,3,"MediumPlatform");
        groundH(145,428,2,"MediumPlatform");
        groundV(271,327,3,"Platform");
        addObject(new Breakable(),299,50);
        addObject(new enemy2(),700,540);
        addObject(new Spikes(),600,245);
        addObject(new Spikes(),182,393);
        addObject(new Spikes(),1030,400);
        addObject(new Breakable(),242,504);
        addObject(new Breakable(),242,523);
    }
}
