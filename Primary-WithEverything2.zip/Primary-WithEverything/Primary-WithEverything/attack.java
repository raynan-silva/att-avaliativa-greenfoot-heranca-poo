import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class attack here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class attack extends Actor
{
    private int timer = 0;
    private GifImage attackAnimation = new GifImage("player_attack.gif");
    /**
     * Act - do whatever the attack wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act()
    {
        setImage(attackAnimation.getCurrentImage());
        timer = timer + 500;
        destroySelf(timer);
        followPlayer(timer);
    }
    private void destroySelf(int time){
        if(time > 5500){
            getWorld().removeObject(this);
        }
    }
    private void followPlayer(int time){
        if (time < 5500){
            if (Greenfoot.isKeyDown("a")){
            setLocation(getX() - 7, getY());
        }
        if (Greenfoot.isKeyDown("d")){
            setLocation(getX() + 7, getY());
        }
        // Sprinting
        if (Greenfoot.isKeyDown("shift")) {
            if (Greenfoot.isKeyDown("a"))
                setLocation(getX() - 4, getY());
            else if (Greenfoot.isKeyDown("d"))
                setLocation(getX() + 4, getY());
        }
        }
    }    
}
