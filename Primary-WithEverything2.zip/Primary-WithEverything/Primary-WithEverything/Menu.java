import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.util.List;
import java.util.ArrayList;

/**
 * Write a description of class Menu here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Menu extends World
{
    private List<Ground> PlatformIcons = new ArrayList<>(); 
    /**
     * Constructor for objects of class Menu.
     * 
     */
    public Menu()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(1100, 600, 1);
    }
    public void groundH (int x, int y, int num, String type){
    for(int i = 0; i < num; i++) {
        switch(type){
            case "LongPlatform":
                LongPlatform lPlat = new LongPlatform();
                addObject(lPlat, x+(i*lPlat.getImage().getWidth()), y);
                PlatformIcons.add(lPlat);
                break;
            case "MediumPlatform":
                MediumPlatform mPlat = new MediumPlatform();
                addObject(mPlat, x+(i*mPlat.getImage().getWidth()), y);
                PlatformIcons.add(mPlat);
                break;
            case "Dirt":
                Dirt dPlat = new Dirt();
                addObject(dPlat, x+(i*dPlat.getImage().getWidth()), y);
                PlatformIcons.add(dPlat);
                break;
            case "VerticlePlatform":
                VerticlePlatform vPlat = new VerticlePlatform();
                addObject(vPlat, x+(i*vPlat.getImage().getWidth()), y);
                PlatformIcons.add(vPlat);
                break;
            case "Platform":
                Platform pPlat = new Platform();
                addObject(pPlat, x+(i*pPlat.getImage().getWidth()), y);
                PlatformIcons.add(pPlat);
                break;
    }
    }
}
    public void groundV (int x, int y, int num, String type){
    for(int i = 0; i < num; i++) {
        switch(type){
            case "LongPlatform":
                LongPlatform lPlat = new LongPlatform();
                addObject(lPlat, x, y+(i*lPlat.getImage().getHeight()));
            PlatformIcons.add(lPlat);
            break;
            case "Platform":
                Platform pPlat = new Platform();
                addObject(pPlat, x, y+(i*pPlat.getImage().getHeight()));
            PlatformIcons.add(pPlat);
            break;
            case "Dirt":
                Dirt dPlat = new Dirt();
                addObject(dPlat, x, y+(i*dPlat.getImage().getHeight()));
            PlatformIcons.add(dPlat);
            break;
            case "MediumPlatform":
                MediumPlatform mPlat = new MediumPlatform();
                addObject(mPlat, x, y+(i*mPlat.getImage().getHeight()));
            PlatformIcons.add(mPlat);
            break;
        }
            }
    }
}
