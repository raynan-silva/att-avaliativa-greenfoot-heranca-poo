import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.util.List; 
/**
 * Write a description of class enemy here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class enemy2 extends Obstacles
{
    private int vertSpeed;
    private int acceleration = 3;
    private boolean alive = true;
    private String orientation = "left";
    private int dir = 1; 
    private GifImage walkingTiger = new GifImage("tigerRunRight.gif");
    private GifImage walkingTigerLeft = new GifImage("tigerRunLeft.gif");
    
    public enemy2(){
    }
    /**
     * Act - do whatever the enemy wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act()
    {
        checkRightWall();
        //checkLeftWall();
        if(alive){
            animationHandle();
            if(alive){
                checkFall();
                if(onGround())
                autoMovement();
            }
        }
    
    }
    public void checkFall()
    {
        if (onGround()) {
            vertSpeed = 0;
            
        } else {
            fall();
        }
    }
    public void fall()
    {
        setLocation(getX(), getY() + vertSpeed);
        vertSpeed += acceleration;
    }
    public boolean onGround()
    {
        Ground under = null;
        int counter = 1;
        int max = vertSpeed;
        while (counter <= max && under == null) {
            under = (Ground) getOneObjectAtOffset(0, getImage().getHeight() / 2 + counter, Ground.class);
            counter++;
        }
        if (under != null) {
            int newY = under.getY() - (under.getImage().getHeight() / 2) - (getImage().getHeight() / 2) - 1;
            setLocation(getX(), newY);
        }
        return under != null;
    }
    public void autoMovement(){
    move(dir * 4); // move based on direction and speed

    // Check if there's ground ahead
    if (!isGroundAhead()||checkRightWall()||checkLeftWall()){//||!checkRightWall()) {
        dir = -dir; // reverse direction if no ground ahead
    }
    }
    public boolean isGroundAhead() {
    int offsetX = dir * getImage().getWidth() / 2; // look a bit ahead in the direction moving
    int offsetY = getImage().getHeight() / 2 + 4;  // look slightly below feet

    Ground ground = (Ground) getOneObjectAtOffset(offsetX, offsetY, Ground.class);
    return (ground != null);
    }
    
    private boolean checkRightWall(){
        int enemyWidth = getImage().getWidth();
        int rightXDistance = enemyWidth/2;
        Ground rightWall = (Ground) getOneObjectAtOffset(rightXDistance, 0, Ground.class);
        if (rightWall == null) return false;
        //rightWallStop(rightWall);
        return true;
    }
    private void rightWallStop(Actor rightWall)
    {
        int wallWidth = rightWall.getImage().getWidth();
        int newX = rightWall.getX()-(wallWidth+getImage().getWidth())/2;
        setLocation(newX, getY());
    }
    private boolean checkLeftWall(){
        int catWidth = getImage().getWidth();
        int leftXDistance = catWidth/-2;
        Actor leftWall = getOneObjectAtOffset(leftXDistance, 0, Ground.class);
        if (leftWall == null) return false;
        leftWallStop(leftWall);
        return true;
    }
    private void leftWallStop(Actor leftWall)
    {
        int wallWidth = leftWall.getImage().getWidth();
        int newX = leftWall.getX()+(wallWidth+getImage().getWidth())/2;
        setLocation(newX, getY());
    }
    public void animationHandle(){
        if(dir > 0)
        setImage(walkingTiger.getCurrentImage());
        if(dir < 0)
        setImage(walkingTigerLeft.getCurrentImage());
    }
}
