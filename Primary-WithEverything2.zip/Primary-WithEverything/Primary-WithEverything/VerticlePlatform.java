import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Verticle_Platform here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class VerticlePlatform extends Ground
{
    public VerticlePlatform(){
        getImage().scale(getImage().getWidth(), getImage().getHeight()+145);
    }
    /**
     * Act - do whatever the Verticle_Platform wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act()
    {
        // Add your action code here.
    }
}
