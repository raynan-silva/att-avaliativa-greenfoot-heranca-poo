import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class World3 here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class World3 extends Menu
{
    private boolean gamestart = true;
    /**
     * Constructor for objects of class World3.
     * 
     */
    public World3()
    {
        prepare();
    }
    public void setup(Lives lives, BlackCat cat, Counter counter, sessionScore ss){
        addObject(cat, 41, 391);
        //addObject(sb, 900, 30);
        addObject(lives, 30, 28);
        addObject(counter, 900, 30);
        addObject(new Door(lives, cat, counter, ss), 1077, 540);
        prepare();
    }
    private void prepare()
    {
        groundH(534,250,6,"MediumPlatform");
        groundH(18,594,2,"VerticlePlatform");
        groundH(707,390,1,"MediumPlatform");
        groundH(843,387,2,"MediumPlatform");
        groundH(634,560,5,"MediumPlatform");
        groundH(1075,599,1,"MediumPlatform");
        groundV(395,355,1,"Platform");
        groundV(974,20,9,"Platform");
        addObject(new enemy(),530,192);
        addObject(new Spikes(),797,431);
        addObject(new Spikes(),195,589);
        addObject(new Spikes(),317,588);
	addObject(new Spikes(),431,589);
	addObject(new Spikes(),538,587);
	addObject(new Spikes(),978,588);
	addObject(new Invisivel(), 580, 389);
    }
}
