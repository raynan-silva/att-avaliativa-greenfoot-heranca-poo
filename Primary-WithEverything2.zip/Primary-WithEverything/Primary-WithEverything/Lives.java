import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.util.ArrayList;
import java.util.List;
/**
 * Write a description of class Lives here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Lives extends Actor
{
    public int lives = 9;
    private List<heart> heartIcons = new ArrayList<>();
    /**
     * Act - do whatever the Lives wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public Lives(){
    setImage(new GreenfootImage(1, 1));
    }
     protected void addedToWorld(World world) {
        updateImage();
    }    public void SubtractLives(){
    lives--;
    updateImage();
    
    }
    private void updateImage(){
    
     World world = getWorld();
        if (world == null) return;

        // Clear existing hearts
        for (heart Heart : heartIcons) {
            world.removeObject(Heart);
        }
        heartIcons.clear();

        // Add current number of hearts
        for (int i = 0; i < lives; i++) {
            heart Heart = new heart();
            world.addObject(Heart, getX() + i * 35, getY());
            heartIcons.add(Heart);
    }
    }
    public int getValue(){
    return lives;
    }
}