/**
 * Write a description of class sessionScore here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class sessionScore  
{
    // instance variables - replace the example below with your own
    public int totalScore = 0;
    /**
     * Constructor for objects of class sessionScore
     */
    public sessionScore()
    {
    }

    /**
     * An example of a method - replace this comment with your own
     * 
     * @param  y   a sample parameter for a method
     * @return     the sum of x and y 
     */
    public void updateScore(int y)
    {
        // put your code here
        totalScore = totalScore + y;
    }
    public int getSessionScore(){
        return totalScore;
    }
    
}
